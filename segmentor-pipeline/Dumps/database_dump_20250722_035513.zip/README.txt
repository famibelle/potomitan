Database Dump - 2025-07-22T01:55:24.191Z

Contient 8 tables:
contributeur
fichiers_audio
langue
methode
notifications
statut_transcription
transcription
transcriptions